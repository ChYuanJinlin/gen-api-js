

export  class App {
    constructor(config) {
        this.config = config;
    }

    gotoProject(url) {

    }

}