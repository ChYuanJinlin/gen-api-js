

## [0.0.7](https://github.com/ChYuanJinlin/gen-api-js/compare/v0.0.4...v0.0.7) (2024-12-04)


###  问题修复

* 修改生成ts 模板 没有请求类型 ([6c39e52](https://github.com/ChYuanJinlin/gen-api-js/commit/6c39e522e08be009f18efcb4ae4689014a223f4a))


###  文档

* **修改文档:** 修改文档 ([ea38f53](https://github.com/ChYuanJinlin/gen-api-js/commit/ea38f53bdb10b9352779cd43d1b51724308c9eaa))

## [0.0.4](https://github.com/ChYuanJinlin/gen-api-js/compare/v0.0.2...v0.0.4) (2024-11-28)


### ✨新功能

* 添加新的功能配置 ([8606433](https://github.com/ChYuanJinlin/gen-api-js/commit/860643338b67e0760f47f38b28f4a6b1f0353309))
* 新增build.js ([9a23323](https://github.com/ChYuanJinlin/gen-api-js/commit/9a23323ae03ce1813dadb4d1a548314b4fcf799c))
* 增加push 命令 ([bc9910f](https://github.com/ChYuanJinlin/gen-api-js/commit/bc9910fc4e4c03906bc18d41751ca2aa867551a1))


###  问题修复

* 去掉api.config.js 忽略文件 ([ccd2704](https://github.com/ChYuanJinlin/gen-api-js/commit/ccd2704b26df1472acaf1cfb398baad54f2597c1))
* **修改文件生成问题:** 修改文件函数重复生成， 生成函数的路径和请求参数不匹配 ([4fd1e35](https://github.com/ChYuanJinlin/gen-api-js/commit/4fd1e351846cf5334324ab5b9fac5974e382fabc))

## [0.0.3](https://github.com/ChYuanJinlin/gen-api-js/compare/v0.0.2...v0.0.3) (2024-11-27)


### ✨新功能

* 添加新的功能配置 ([8606433](https://github.com/ChYuanJinlin/gen-api-js/commit/860643338b67e0760f47f38b28f4a6b1f0353309))
* 新增build.js ([9a23323](https://github.com/ChYuanJinlin/gen-api-js/commit/9a23323ae03ce1813dadb4d1a548314b4fcf799c))
* 增加push 命令 ([bc9910f](https://github.com/ChYuanJinlin/gen-api-js/commit/bc9910fc4e4c03906bc18d41751ca2aa867551a1))

# Changelog

All notable changes to this project will be documented in this file. See [standard-version](https://github.com/conventional-changelog/standard-version) for commit guidelines.

### [0.0.2](https://github.com/ChYuanJinlin/gen-api-js/compare/v0.0.1...v0.0.2) (2024-11-27)


### Features

* 添加新的功能配置 ([991f63b](https://github.com/ChYuanJinlin/gen-api-js/commit/991f63b60fcdff1fdac2f2e4895e0588758a5b87))
* 新增ci cd ([e6cf8b8](https://github.com/ChYuanJinlin/gen-api-js/commit/e6cf8b862b350e188553c2e994229fb4392f6d57))

### 0.0.1 (2024-11-27)


### Features

* git-api-js@0.0.1 ([38c3fcc](https://github.com/ChYuanJinlin/gen-yapi/commit/38c3fccb931ea8ee3da017df2962ecc0f36917df))
